# NLP_assignment1

used nltk,numpy,pandas for count the , sk_learn and time libraries  
after downloading the above packages run the second loop which will five the probability of transition probability
after that the next cell will give the results of emmision probabilities
the next cell is veterbi model where we get the hmm chain
In viterbi if there is no words we calculated the probability of an unknown words using the previous word pos tag
For a given dataset to caluculate the accuracy we used 5-fold model we split the 4 parts as train data set, 
and from that dataset we caluculate transistion and emmision matrix and for the test dataset we pass the words in a sentence to viterbi 
In viterbi it caluculate transition and emmision for a given word using previous word pos tag, from that it caluclate the pos of the given word
For caluculating emmision we use nltk library to find tag frequency,from that we find the respective probabilities.
 

